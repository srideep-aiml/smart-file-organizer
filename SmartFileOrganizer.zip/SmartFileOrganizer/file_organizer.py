import os
import shutil
from pathlib import Path
from datetime import datetime

# ============================================================
# SMART FILE ORGANIZER
# ============================================================

# File categories and their extensions
FILE_CATEGORIES = {
    "Images": [
        ".jpg", ".jpeg", ".png", ".gif", ".bmp",
        ".webp", ".svg", ".tiff"
    ],

    "Documents": [
        ".pdf", ".doc", ".docx", ".txt", ".rtf",
        ".odt"
    ],

    "Spreadsheets": [
        ".xls", ".xlsx", ".csv", ".ods"
    ],

    "Presentations": [
        ".ppt", ".pptx", ".odp"
    ],

    "Videos": [
        ".mp4", ".mkv", ".avi", ".mov", ".wmv",
        ".flv", ".webm"
    ],

    "Music": [
        ".mp3", ".wav", ".aac", ".flac", ".ogg",
        ".m4a"
    ],

    "Archives": [
        ".zip", ".rar", ".7z", ".tar", ".gz"
    ],

    "Programs": [
        ".exe", ".msi", ".apk", ".bat", ".sh"
    ]
}


# ------------------------------------------------------------
# Find the category of a file
# ------------------------------------------------------------
def get_category(file_extension):
    """Return the folder category based on file extension."""

    file_extension = file_extension.lower()

    for category, extensions in FILE_CATEGORIES.items():
        if file_extension in extensions:
            return category

    return "Others"


# ------------------------------------------------------------
# Create category folders
# ------------------------------------------------------------
def create_folders(folder_path):
    """Create folders for all categories."""

    categories = list(FILE_CATEGORIES.keys())
    categories.append("Others")

    for category in categories:
        category_path = folder_path / category

        if not category_path.exists():
            category_path.mkdir()

    print("\nFolders created successfully.")


# ------------------------------------------------------------
# Generate a unique destination filename
# ------------------------------------------------------------
def get_unique_destination(destination):
    """
    If a file with the same name already exists,
    create a new filename instead of overwriting it.
    """

    if not destination.exists():
        return destination

    counter = 1

    while True:
        new_name = (
            destination.stem
            + f"_{counter}"
            + destination.suffix
        )

        new_destination = destination.parent / new_name

        if not new_destination.exists():
            return new_destination

        counter += 1


# ------------------------------------------------------------
# Organize files
# ------------------------------------------------------------
def organize_files(folder_path):
    """Organize files according to their extensions."""

    moved_files = 0
    skipped_files = 0

    # Get all items inside the selected folder
    for item in folder_path.iterdir():

        # Ignore folders
        if item.is_dir():
            continue

        # Ignore the Python program itself
        if item.name == Path(__file__).name:
            continue

        # Get file extension
        extension = item.suffix

        # Find category
        category = get_category(extension)

        # Destination folder
        destination_folder = folder_path / category

        # Make sure destination folder exists
        destination_folder.mkdir(exist_ok=True)

        # Destination file
        destination = destination_folder / item.name

        # Avoid overwriting files
        destination = get_unique_destination(destination)

        try:
            shutil.move(str(item), str(destination))

            print(
                f"Moved: {item.name} "
                f"--> {category}/{destination.name}"
            )

            moved_files += 1

        except PermissionError:
            print(f"Permission denied: {item.name}")
            skipped_files += 1

        except Exception as error:
            print(f"Could not move {item.name}: {error}")
            skipped_files += 1

    return moved_files, skipped_files


# ------------------------------------------------------------
# Display summary
# ------------------------------------------------------------
def display_summary(moved_files, skipped_files):
    print("\n" + "=" * 50)
    print("             ORGANIZATION COMPLETE")
    print("=" * 50)

    print(f"Files moved   : {moved_files}")
    print(f"Files skipped : {skipped_files}")

    print("=" * 50)


# ------------------------------------------------------------
# Main function
# ------------------------------------------------------------
def main():

    print("=" * 50)
    print("          SMART FILE ORGANIZER")
    print("=" * 50)

    print("\nThis program organizes files based on their type.")
    print("Example: PDF -> Documents, JPG -> Images")

    # Ask user for folder path
    folder_input = input(
        "\nEnter the folder path to organize: "
    ).strip()

    # Remove quotes if user copied path with quotes
    folder_input = folder_input.strip('"').strip("'")

    folder_path = Path(folder_input)

    # Check whether folder exists
    if not folder_path.exists():
        print("\nError: The specified folder does not exist.")
        return

    # Check whether it is actually a folder
    if not folder_path.is_dir():
        print("\nError: The specified path is not a folder.")
        return

    print(f"\nSelected folder: {folder_path}")

    # Create category folders
    create_folders(folder_path)

    # Organize files
    moved_files, skipped_files = organize_files(folder_path)

    # Display final result
    display_summary(moved_files, skipped_files)

    print("\nThank you for using Smart File Organizer!")


# ------------------------------------------------------------
# Program starts here
# ------------------------------------------------------------
if __name__ == "__main__":
    main()
